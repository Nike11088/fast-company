import EditUserPage from './editUserPage'
export default EditUserPage
