import React, { useEffect, useState } from 'react'
import { useParams, useHistory } from 'react-router-dom'
import { validator } from '../../../utils/validator'
import TextField from '../../common/form/textField'
import SelectField from '../../common/form/selectField'
import RadioField from '../../common/form/radioField'
import MultiSelectField from '../../common/form/multiSelectField'
import BackHistoryButton from '../../common/backButton'
import { useQualities } from '../../../hooks/useQualities'
import { useProfessions } from '../../../hooks/useProfession'
import { useUser } from '../../../hooks/useUsers'
import { useAuth } from '../../../hooks/useAuth'

const EditUserPage = () => {
    const { currentUser } = useAuth()
    console.log(currentUser)
    const history = useHistory()
    const { userId } = useParams()
    const { getUserById, updateUser } = useUser()
    const user = getUserById(userId)

    const [data, setData] = useState({
        name: '',
        email: '',
        profession: '',
        sex: 'male',
        qualities: []
    })
    const [isLoading, setIsLoading] = useState(false)
    const [errors, setErrors] = useState({})

    const { qualities, getQuality } = useQualities()
    const { professions } = useProfessions()

    // const getProfessionById = (id) => {
    //     return professions.filter((prof) => prof._id === id)
    //     // for (const prof of professions) {
    //     //     if (prof.value === id) {
    //     //         return { _id: prof.value, name: prof.label }
    //     //     }
    //     // }
    // }
    // const getQualities = (elements) => {
    //     const qualitiesArray = []
    //     for (const elem of elements) {
    //         for (const quality in qualities) {
    //             if (elem.value === qualities[quality].value) {
    //                 qualitiesArray.push({
    //                     _id: qualities[quality].value,
    //                     name: qualities[quality].label,
    //                     color: qualities[quality].color
    //                 })
    //             }
    //         }
    //     }
    //     return qualitiesArray
    // }
    const handleSubmit = async (e) => {
        e.preventDefault()
        const isValid = validate()
        if (!isValid) return

        const { qualities } = data

        updateUser({
            ...data,
            qualities: qualities.map((quality) => quality.value)
        })

        history.push(`/users/${data._id}`)

        // const { profession, qualities } = data
        // api.users
        //     .update(userId, {
        //         ...data,
        //         profession: getProfessionById(profession),
        //         qualities: getQualities(qualities)
        //     })
        //     .then((data) => history.push(`/users/${data._id}`))
    }
    const transformData = (data) => {
        return data.map((qual) => ({ label: qual.name, value: qual._id }))

        // if (Array.isArray(data)) {
        //     return data.map((qual) => ({ label: qual.name, value: qual._id }))
        // }

        // return { label: data.name, value: data._id }
    }
    useEffect(async () => {
        // if (currentUser._id !== user._id) {
        //     console.log(currentUser._id)
        //     history.push(`/users/${currentUser._id}/edit`)
        //     return null
        // }
        const userQualities = user.qualities.map((qualityId) =>
            getQuality(qualityId)
        )
        setData(() => ({
            ...user,
            qualities: transformData(userQualities),
            profession: user.profession
        }))
    }, [])
    useEffect(() => {
        if (data._id) setIsLoading(false)
        validate()
    }, [data])

    const validatorConfig = {
        email: {
            isRequired: {
                message: 'Электронная почта обязательна для заполнения'
            },
            isEmail: {
                message: 'Email введен некорректно'
            }
        },
        name: {
            isRequired: {
                message: 'Введите ваше имя'
            }
        }
    }

    const handleChange = (target) => {
        setData((prevState) => ({
            ...prevState,
            [target.name]: target.value
        }))
    }
    const validate = () => {
        const errors = validator(data, validatorConfig)
        setErrors(errors)
        return Object.keys(errors).length === 0
    }
    const isValid = Object.keys(errors).length === 0

    return (
        <div className="container mt-5">
            <BackHistoryButton />
            <div className="row">
                <div className="col-md-6 offset-md-3 shadow p-4">
                    {!isLoading && Object.keys(professions).length > 0 ? (
                        <form onSubmit={handleSubmit}>
                            <TextField
                                label="Имя"
                                name="name"
                                value={data.name}
                                onChange={handleChange}
                                error={errors.name}
                            />
                            <TextField
                                label="Электронная почта"
                                name="email"
                                value={data.email}
                                onChange={handleChange}
                                error={errors.email}
                            />
                            <SelectField
                                label="Выбери свою профессию"
                                defaultOption="Choose..."
                                options={transformData(professions)}
                                name="profession"
                                onChange={handleChange}
                                value={data.profession.value}
                                error={errors.profession}
                            />
                            <RadioField
                                options={[
                                    { name: 'Male', value: 'male' },
                                    { name: 'Female', value: 'female' }
                                ]}
                                value={data.sex}
                                name="sex"
                                onChange={handleChange}
                                label="Выберите ваш пол"
                            />
                            <MultiSelectField
                                defaultValue={data.qualities}
                                options={transformData(qualities)}
                                onChange={handleChange}
                                name="qualities"
                                label="Выберите ваши качества"
                            />
                            <button
                                type="submit"
                                disabled={!isValid}
                                className="btn btn-primary w-100 mx-auto"
                            >
                                Обновить
                            </button>
                        </form>
                    ) : (
                        'Loading...'
                    )}
                </div>
            </div>
        </div>
    )
}

export default EditUserPage
