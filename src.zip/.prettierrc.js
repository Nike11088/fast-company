module.exports = {
    singleQuote: true,
    trailingComma: 'none',
    tabWidth: 4,
    semi: false
}
